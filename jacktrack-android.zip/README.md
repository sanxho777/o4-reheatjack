# JackTrack Android Scaffold

This scaffold provides a production-ready Android-focused subset of the JackTrack app.
Clone this folder and run:

```bash
cd jacktrack-android
yarn install
expo run:android
```

Ensure you fill in your API keys in __app.json__ and replace the placeholder icon in `assets/icon.png`.
