export const colors = {
  primary: '#006400',
  accent: '#FFD700',
  background: '#FFFFFF',
  text: '#333333'
};
